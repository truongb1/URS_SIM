# Driving-Simulator
SIMHUB Cluster implementations for Driving Simulator

[xConnect cluster implementations info](https://github.com/InfoX1337/xConnect-hardware/tree/main)

[CANBus Library](https://github.com/coryjfowler/MCP_CAN_lib)

[Ford Focus Implimentations](https://github.com/InfoX1337/xConnect-hardware/branches)

[https://wiki.openstreetmap.org/wiki/VW-CAN#288_8_10ms_Motor_2](https://wiki.openstreetmap.org/wiki/VW-CAN)https://wiki.openstreetmap.org/wiki/VW-CAN

https://hackaday.io/project/6288-can-bus-gaming-simulator

https://www.t4-wiki.de/wiki/Kombiinstrument#Versionen
